"""
lorentz_transformer/core/__init__.py

Component 1: Minkowski几何核心模块

包含所有闵可夫斯基注意力机制相关的组件。
"""

from .attention import (
    LorentzMultiHeadAttention,
    compute_dt2_info,
    hutchinson_diag_hessian,
)

__all__ = [
    "LorentzMultiHeadAttention",
    "compute_dt2_info",
    "hutchinson_diag_hessian",
]
